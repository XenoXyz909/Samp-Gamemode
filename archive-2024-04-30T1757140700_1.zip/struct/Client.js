const { Client, Collection, Partials } = require('discord.js');

module.exports = class extends Client {
	constructor(config) {
		super({
			disableMentions: 'everyone',
			partials: [ Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember ],
			intents: [3276799]
		});

		this.commands = new Collection();

		this.config = config;
	}
}
