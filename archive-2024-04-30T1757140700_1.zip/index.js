//require('dotenv').config();

const { stripIndents } = require("common-tags");
const structClient = require("./struct/Client.js");
const { ActivityType } = require("discord.js");
const server = require("./function/server-stats.js");
const { EmbedBuilder } = require("discord.js");
const fs = require("fs");
const client = new structClient({
  token: "",
  clientId: "id bot",
  db_host: "",
  db_user: "",
  db_password: "",
  db_name: "s24_ranum",
});

const handler = fs
  .readdirSync("./handler")
  .filter((file) => file.endsWith(".js"));
const commandFiles = fs
  .readdirSync("./commands")
  .filter((file) => file.endsWith("js"));
const eventFiles = fs
  .readdirSync("./events")
  .filter((file) => file.endsWith(".js"));

(async () => {
  connection = await require("./database/mysql");

  for (file of handler) {
    require(`./handler/${file}`)(client);
  }

  client.handleEvents(eventFiles, "./events");
  client.handleCommands(commandFiles, "./commands");
  client.login(client.config.token);
})();

/*client.on('ready', () => 
{
	client.user.setActivity(`Exotic Life Community`, {type: ActivityType.Listening})
});*/

client.on("ready", () => {
  console.log(`${client.user.tag} online!`);
  setInterval(() => {
    server
      .stats()
      .then((data) => {
        client.user.setActivity(
          `📊 [${data.online}/${data.maxplayers}] | Ranum Roleplay`,
          { type: ActivityType.Playing }
        );
      })
      .catch((error) => {
        console.log('بِسْمِ ٱللَّٰهِ:', error);
      });
  }, 60000);
});

client.on("guildMemberAdd", (member) => {
  const channelID = "1171284962683654184"; // Ganti dengan ID channel yang ingin Anda gunakan
  const channel = member.guild.channels.cache.get(channelID);
  if (!channel) return; // Memastikan channel log ditemukan
  const embed = new EmbedBuilder()
    .setTitle(`Selamat datang, ${member.user.tag}!`)
    .setDescription(
      stripIndents`
	  - Silahkan Baca ⁠<#1171285019751362592> dan ⁠<#1171285022683185263>⁠
	  - Akses aku panel di ⁠<#1171285854954717184>
	  - Bergabunglah dengan tertib agar warga #RANUM respect dengan kalian
	  - Jika butuh bantuan silahkan hubungi <@&1171284517533786146>`
    )

    .setColor(
      member.displayHexColor === "#000000" ? "#ffffff" : member.displayHexColor
    )
    .setColor("#34cceb")
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 128 }))
    .setTimestamp();
  channel.send({ embeds: [embed] });
});
