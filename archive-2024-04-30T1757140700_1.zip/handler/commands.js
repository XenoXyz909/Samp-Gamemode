const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');

module.exports = (client) => {

    const clientId = client.config.clientId;

    client.handleCommands = async (commandFiles, path) => {
        client.commandArray = [];

        for (const file of commandFiles) {
            const command = require(`../commands/${file}`);

            if (command.data) {
                client.commands.set(command.data.name, command);
                client.commandArray.push(command.data.toJSON());
            } 
        }

        for (let file of commandFiles) {
            let pull = require(`../commands/${file}`);
            
            if (pull.name) {
                client.commands.set(pull.name, pull);
            } else {
                continue;
            }
        }

        console.log(`INFO: ${client.commands.size} commands has been loaded!`);

        const rest = new REST({ version: '10' }).setToken(client.config.token);

        (async () => {
            try {
                console.log('INFO: Loading the slash (/) commands...');

                await rest.put(
                    Routes.applicationCommands(clientId),
                    { body: client.commandArray },
                );

                console.log('INFO: Successfully loaded the slash (/) commands.');
            } catch (error) {
                console.error(error);
            }
        })();

    }
}