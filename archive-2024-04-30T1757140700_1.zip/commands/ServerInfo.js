const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits } = require('discord-api-types/v10');
const { stripIndents } = require('common-tags');

module.exports = {
    name: 'showserverinfo',
    data: new SlashCommandBuilder()
        .setName('showserverinfo')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDescription('show server information (ADMIN ONLY)'),

        async execute(int) {
            const c_member = await int.guild.members.fetch(int.client.user.id, { force: true });
            const serInfo = new EmbedBuilder()
                .setColor(c_member.displayHexColor === '#000000' ? '#ffffff' : c_member.displayHexColor)
                .setTitle(`**:wave: Welcome to Ranum Roleplay**`)
                .setDescription(stripIndents`           
                Ranum Roleplay adalah komunitas bermain peran berbasis voice menggunakan bahasa indonesia untuk San Andreas Multiplayer (SA-MP).\n
                Menampilkan dunia peran yang luar biasa dengan lingkungan yang unik, dan sebuah meta yang kaya fitur, yang terus berkembang.\n
                Disediakan untuk semua orang oleh tim yang bersemangat dengan pengalaman pengembangan selama bertahun-tahun. Berdiri di belakang spanduk yang mendefinisikan, menjadi pionir, dan berkembang sebagai benteng terakhir peran SA-MP.
                `)
                .addFields(  
                    { name: ':sparkles: Get Started!', value: '<#1171285854954717184>', inline: true },
                    { name: '🎮 Connect', value: '||Ananta Ganteng||', inline: true },
                    { name: ':thought_balloon: Need Help?', value: '<#1174240113509814292>', inline: true },
                )
                .setImage('https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=')
                .setFooter({ text: 'Introduction', iconURL: 'https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=' });



        await int.channel.send({ embeds: [serInfo]}).catch(err => console.log(err.message));

        await int.reply({ content: 'You\'ve loaded the server information!', ephemeral: true });

    }
}
