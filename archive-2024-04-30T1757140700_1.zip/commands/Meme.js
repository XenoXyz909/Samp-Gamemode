const { SlashCommandBuilder } = require('@discordjs/builders');
const snekfetch = require('snekfetch');
const randomPuppy = require('random-puppy');

module.exports = {
    name: 'meme',
    data: new SlashCommandBuilder()
        .setName('meme')
        .setDMPermission(false)
        .setDescription('meme'),

    async execute(message) {
        try {
            const { body } = await snekfetch.get('https://www.reddit.com/r/memes/random.json');
            const memeURL = body[0].data.children[0].data.url;
      
            const memeEmbed = new Discord.MessageEmbed()
              .setColor('#ff4500')
              .setTitle('Random Meme')
              .setImage(memeURL)
              .setTimestamp()
              .setFooter('Meme fetched from r/memes');
      
            message.channel.send(memeEmbed);
        } catch (error) {
            console.error(error);
            message.channel.send('Failed to fetch a meme, please try again later.');
        }
    }
}
