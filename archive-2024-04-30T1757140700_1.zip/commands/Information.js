const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits } = require('discord-api-types/v10');

module.exports = {
    name: 'information',
    data: new SlashCommandBuilder()
        .setName('information')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDescription('information (ADMIN ONLY)'),
        
        async execute(int) {

            const registerMenu = new ModalBuilder()
                .setCustomId('informationmodal')
                .setTitle('information Embed');

            const nameInput = new TextInputBuilder()
                .setCustomId('informationTitle')
                .setLabel("Judul:")
                .setStyle(TextInputStyle.Short)
                .setMaxLength(64)
                .setMinLength(4)
                .setRequired(true);

            const passwordInput = new TextInputBuilder()
                .setCustomId('informationMain')
                .setLabel("Isi:")
                .setStyle(TextInputStyle.Paragraph)
                .setMinLength(8)
                .setRequired(true);

            const firstActionRow = new ActionRowBuilder().addComponents(nameInput);
            const secondActionRow = new ActionRowBuilder().addComponents(passwordInput);

            registerMenu.addComponents(firstActionRow, secondActionRow);

            try {
                await int.showModal(registerMenu)
                    .catch(err => console.log(err.message));
            } catch(err) {
                console.log(err.message);
            }
    }
}