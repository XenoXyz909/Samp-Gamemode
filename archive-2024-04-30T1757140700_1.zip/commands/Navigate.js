const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits } = require('discord-api-types/v10');
const { stripIndents } = require('common-tags');

module.exports = {
    name: 'shownavigate',
    data: new SlashCommandBuilder()
        .setName('shownavigate')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDescription('show server information (ADMIN ONLY)'),
        async execute(int) {
            const c_member = await int.guild.members.fetch(int.client.user.id, { force: true });
            const serInfo = new EmbedBuilder()
                .setColor(c_member.displayHexColor === '#000000' ? '#ffffff' : c_member.displayHexColor)
                .setTitle(`**:link: Navigate**`)
                .addFields(  
                    { name: 'Get Started', value: '<#1171285854954717184>\n<#1171285009827643412>\n<#1171285019751362592>', inline: true },
                    { name: 'Recommended', value: '<#1171285025996677220>\n<#1171285060071202816>\n<#1171285011681513503>', inline: true },
                    { name: 'Network', value: '<#1171285009827643412>', inline: true },
                )
                .setFooter({ text: 'Navigate', iconURL: 'https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=' });



        await int.channel.send({ embeds: [serInfo]}).catch(err => console.log(err.message));

        await int.reply({ content: 'You\'ve loaded the navigate!', ephemeral: true });

    }
}
