const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits } = require('discord-api-types/v10');
const { stripIndents } = require('common-tags');

module.exports = {
    name: 'showip',
    data: new SlashCommandBuilder()
        .setName('showip')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDescription('show server information (ADMIN ONLY)'),
        async execute(int) {
            const c_member = await int.guild.members.fetch(int.client.user.id, { force: true });
            const serInfo = new EmbedBuilder()

                .setColor(c_member.displayHexColor === '#000000' ? '#ffffff' : c_member.displayHexColor)
                .setTitle(`**🌐 Ranum Statistic**`)
                .addFields(  
                    { name: 'Hostname', value: 'Ranum Roleplay | 1.0 Launched!'},
                    { name: 'Address', value: '157.254.166.212:7011'},
                    { name: 'Ping', value: 'Menyesuaikan Internetmu/Koneksimu'},
                    { name: 'Player', value: '0/200'},
                    { name: 'Language', value: 'Bahasa Indonesia'}
                )
                .setFooter({ text: 'IP SERVER', iconURL: 'https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=' });



        await int.channel.send({ embeds: [serInfo]}).catch(err => console.log(err.message));

        await int.reply({ content: 'You\'ve loaded the IP SERVER', ephemeral: true });

    }
}
