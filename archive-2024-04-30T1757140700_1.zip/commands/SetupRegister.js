const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits } = require('discord-api-types/v10');
const { stripIndents } = require('common-tags');

module.exports = {
    name: 'setupregister',
    data: new SlashCommandBuilder()
        .setName('setupregister')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDescription('Setup the register panel (ADMIN ONLY)'),
        async execute(int) {

            const c_member = await int.guild.members.fetch(int.client.user.id, { force: true });
            
            const regContent = new EmbedBuilder()
                .setAuthor({ name: `${int.client.user.username} | ACCOUNT PANEL`, iconURL: int.client.user.displayAvatarURL({ forceStatic: true }) })
                .setColor('Blue')
                
                .setTitle(`**Account Manager ${int.client.user.username}**`)
                .setDescription(stripIndents`           
                Di channel ini, Anda dapat mengatur akun anda.\n
                Anda dapat membuat akun dengan tombol register.\n
                Anda juga dapat mengganti password login dengan mengklik tombol Change Password.
                `)
                .setTimestamp()
                .setFooter({ text: 'Ranum Community', iconURL: 'https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=' });
    
            const regButtons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('registry')
                        .setLabel('📝 Buat Akun')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('checkaccount')
                        .setLabel('🕵️ Cek Akun')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('verifybtn')
                        .setLabel('👤 Ambil Role')
                        .setStyle(ButtonStyle.Primary),
                    /*new ButtonBuilder()
                        .setCustomId('requestcn')
                        .setLabel('✏️ Request Changename')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),*/
                    new ButtonBuilder()
                        .setCustomId('changepassword')
                        .setLabel('🔑 Ganti Password')
                        .setStyle(ButtonStyle.Danger),
                    
            ); 

        await int.channel.send({ embeds: [regContent], components: [regButtons] }).catch(err => console.log(err.message));

        await int.reply({ content: 'You\'ve loaded the register panel!', ephemeral: true });

    }
}