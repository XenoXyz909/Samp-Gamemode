const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits } = require('discord-api-types/v10');
const { stripIndents } = require('common-tags');

module.exports = {
    name: 'showsocialmedia',
    data: new SlashCommandBuilder()
        .setName('showsocialmedia')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDescription('show server information (ADMIN ONLY)'),
        async execute(int) {
            const c_member = await int.guild.members.fetch(int.client.user.id, { force: true });
            const serInfo = new EmbedBuilder()

                .setColor(c_member.displayHexColor === '#000000' ? '#ffffff' : c_member.displayHexColor)
                .setTitle(`**🌐 Social Media**`)
                .setDescription(`Selamat datang di RANUM COMMUNITY
                Kami seluruh Staff Ranum sangat berterima kasih atas kepercayaann kalian telah bergabung dalam Server Roleplay EXOTIC COMMUNITY. Sekarang kalian bisa mengajak Sahabat, teman, pacar kalian bergabung dalam Server Roleplay ini kami menyediakan Link untuk anda bagikan, Sekian yang bisa saya sampaikan Terimakasih.`)
                .addFields(  
                    //{ name: 'Instagram', value: '[IG Exotic](https://instagram.com/dewatacommunity?igshid=Yzg5MTU1MDY=)'},
                    { name: 'WA Grup', value: 'https://chat.whatsapp.com/EChiqivN0RiJxtGJ5djI9v'},
                    //{ name: 'Youtube', value: '[Youtube Resmi Exotic](https://www.youtube.com/@dewataroleplay)'},
                    { name: 'Discord', value: 'https://discord.gg/dewatacommunity'}
                )
                .setFooter({ text: 'Social Media', iconURL: 'https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=' });



        await int.channel.send({ embeds: [serInfo]}).catch(err => console.log(err.message));

        await int.reply({ content: 'You\'ve loaded the social media!', ephemeral: true });

    }
}
