const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits } = require('discord-api-types/v10');

module.exports = {
    name: 'announcement',
    data: new SlashCommandBuilder()
        .setName('announcement')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDescription('announcement (ADMIN ONLY)'),
        
        async execute(int) {

            const registerMenu = new ModalBuilder()
                .setCustomId('announcementmodal')
                .setTitle('Buat Pengumuman');

            /*const nameInput = new TextInputBuilder()
                .setCustomId('announcementTitle')
                .setLabel("Judul:")
                .setStyle(TextInputStyle.Short)
                .setMaxLength(64)
                .setMinLength(4)
                .setRequired(true);*/

            const passwordInput = new TextInputBuilder()
                .setCustomId('announcementMain')
                .setLabel("Isi:")
                .setStyle(TextInputStyle.Paragraph)
                .setMinLength(8)
                .setRequired(true);

            const secondActionRow = new ActionRowBuilder().addComponents(passwordInput);

            registerMenu.addComponents(secondActionRow);

            try {
                await int.showModal(registerMenu)
                    .catch(err => console.log(err.message));
            } catch(err) {
                console.log(err.message);
            }
    }
}