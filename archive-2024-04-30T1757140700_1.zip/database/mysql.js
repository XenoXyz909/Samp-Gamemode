/*const mysql = require('mysql2/promise');

module.exports = mysql.createConnection({
  host: '',
  user: '',
  database: '',
  password: ''
});*/

const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: '',
  user: '',
  password: '',
  database: 's24_ranum',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  // Optional: add any configuration options you need
});

module.exports = pool;


/*const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: '',
  user: '',
  password: '',
  database: 's24_ranum',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

async function getConnection() {
  const connection = await pool.getConnection();
  return connection;
}

// Use the getConnection function to obtain a connection
(async () => {
  const connection = await getConnection();
  try {
    // Use the execute method on the connection object
    const [ rows ] = await connection.execute(
      'SELECT * FROM accounts'
    );
    console.log(rows);
  } finally {
    // Release the connection back to the pool
    connection.release();
  }
})();*/