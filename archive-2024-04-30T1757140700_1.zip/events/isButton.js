module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isButton()) return;

        console.log(`INFO: Click Button ID: ${interaction.customId} [ ${interaction.user.tag} ]`);
    }
}