const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'changepassword') {

            const errorEmbed = new EmbedBuilder()
                .setColor('#e11e1e')
                .setThumbnail('https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=')
                .setTitle('Ganti Sandi - Ranum Roleplay')

            var member = interaction.member;

            const [ rows ] = await connection.execute(
                `SELECT * FROM accounts WHERE DiscordID = ?`, [ `${interaction.user.id}` ]
            );
        
            if (rows.length === 0) {
                await interaction.reply({ embeds: [
                    errorEmbed
                        .setDescription('Kamu tidak memiliki accounts sama sekali.')
                ], ephemeral: true }).catch(err => console.log(err.message));
                return;
            }

            const changepwMenu = new ModalBuilder()
                .setCustomId(`changepwmodal`)
                .setTitle('Ganti Kata Sandi');

            const newPWInput = new TextInputBuilder()
                .setCustomId('newPWInput')
                .setLabel("New Password:")
                .setStyle(TextInputStyle.Short)
                .setMaxLength(64)
                .setMinLength(8)
                .setRequired(true);

            const firstActionRow = new ActionRowBuilder().addComponents(newPWInput);

            changepwMenu.addComponents(firstActionRow);
            try {
                await interaction.showModal(changepwMenu)
                    .catch(err => console.log(err.message));
            } catch(err) {
                console.log(err.message);
            }
        }

    }
}

