const { EmbedBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

let connection;

const bcrypt = require('bcrypt');
const saltRounds = 10;

const blockedSymbols = ['@', '#', '$', '%', '&', '*', '_', ' '];

function hasBlockedSymbols(input) {
    // Create a regex pattern to match the blocked symbols
    const regex = new RegExp(`[${blockedSymbols.join('')}]`);
    // Test if the input contains any blocked symbols
    return regex.test(input);
}

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {

        if (!interaction.isModalSubmit()) return;

        connection = await require('../database/mysql');

        const c_member = await interaction.guild.members.fetch(interaction.client.user.id, { force: true });
    
        if (interaction.customId === 'registrymodal') {
    
            const errorEmbed = new EmbedBuilder()
                .setColor('e31e1e')
                .setThumbnail('https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=')
                .setTitle('Daftar Akun - Ranum Roleplay')
    
            const regEmbed = new EmbedBuilder()
                .setColor(c_member.displayHexColor === '#000000' ? '#ffffff' : c_member.displayHexColor)
    
            const usernameCheck = interaction.fields.getTextInputValue('nameInput');
            const passwordCheck = interaction.fields.getTextInputValue('passwordInput');
            
            try {
                const [ rows ] = await connection.execute(
                    `SELECT * FROM accounts WHERE Username = ?`, [`${usernameCheck}`]
                );
                if (rows.length === 0) {
                    // ini baru di tambah untuk hasblocked
                    if (hasBlockedSymbols(usernameCheck)) {
                        console.log(`ERROR: Account: ${usernameCheck} is ilegal symbol! [ ${interaction.user.tag} ]`);

                        await interaction.reply({ embeds: [
                            errorEmbed
                                .setDescription(`Username \`${usernameCheck}\` Tidak bisa gunakan, buat UCP tanpa menggunakan simbol!`)
                        ], ephemeral: true }).catch(err => console.log(err.message));
                    } else {
                        const password = passwordCheck;
                        await bcrypt.hash(password, saltRounds).then(async function(hash) {
                                await connection.query(
                                    stripIndents`INSERT INTO accounts (Username, password, DiscordID, Active, Registered) 
                                    VALUES('${usernameCheck}', '${hash}', '${interaction.user.id}', '1', '1')`
                                );

                                console.log(`INFO: Account: ${usernameCheck} has successfully registered! [ ${interaction.user.tag} ]`);
                        
                                await interaction.reply({ embeds: [
                                    regEmbed
                                        .setTitle(`Daftar Akun - Ranum Roleplay`)
                                        .setColor('Blue')
                                        .setThumbnail('https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=')
                                        .setDescription(stripIndents`:white_check_mark: Berhasil!
                                        Pendaftaran berhasil dilakukan, berikut adalah Username dan Password kamu!`)
                                        .addFields({ name: "Nama UCP", value: `${usernameCheck}` })
                                        .addFields({ name: "Kata Sandi", value: `||${password}||`})
                                        .addFields({ name: "Note", value: `~ Jangan beritahu informasi ini kepada orang lain! ~`})
                                ], ephemeral: true }).catch(err => console.log(err.message));

                                try {
                                    await interaction.member.setNickname(`${usernameCheck}`);
                                }
                                catch (err){
                                    console.error(err);
                                }
                        });

                    return;
                    }
                    
                } else {
                    console.log(`ERROR: Account: ${usernameCheck} is already registered by someone else! [ ${interaction.user.tag} ]`);

                    await interaction.reply({ embeds: [
                        errorEmbed
                            .setDescription(`Username \`${usernameCheck}\` sudah terdaftar, silahkan gunakan nama lain!`)
                    ], ephemeral: true }).catch(err => console.log(err.message));
                    return;
                }
    
            } catch (err) {
                console.log(err);

                await interaction.reply({ embeds: [
                    errorEmbed
                        .setDescription('Terjadi kesalahan ketika melakukan pendaftaran, silahkan coba lagi.')
                ], ephemeral: true }).catch(err => console.log(err.message));
                return;
            }

        }
    }
}
