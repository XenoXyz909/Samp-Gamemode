module.exports = {
    name: 'ready',
    async execute(client) {

        console.log(`INFO: ${client.user.tag} is now Online!`);
        
    }
}