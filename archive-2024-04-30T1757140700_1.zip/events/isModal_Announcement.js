const { EmbedBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

let connection;

const bcrypt = require('bcrypt');
const saltRounds = 10;

const blockedSymbols = ['@', '#', '$', '%', '&', '*', '_', ' '];

function hasBlockedSymbols(input) {
    // Create a regex pattern to match the blocked symbols
    const regex = new RegExp(`[${blockedSymbols.join('')}]`);
    // Test if the input contains any blocked symbols
    return regex.test(input);
}

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {

        if (!interaction.isModalSubmit()) return;
    
        if (interaction.customId === 'announcementmodal') {
    
            //const AnnouncementTitle = interaction.fields.getTextInputValue('announcementTitle');
            const AnnouncementMain = interaction.fields.getTextInputValue('announcementMain');
            

            await interaction.channel.send(`${AnnouncementMain}`).catch(err => console.log(err.message));
        }
    }
}
