const { EmbedBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

let connection;

const bcrypt = require('bcrypt');
const saltRounds = 10;

const blockedSymbols = ['@', '#', '$', '%', '&', '*', '_', ' '];

function hasBlockedSymbols(input) {
    // Create a regex pattern to match the blocked symbols
    const regex = new RegExp(`[${blockedSymbols.join('')}]`);
    // Test if the input contains any blocked symbols
    return regex.test(input);
}

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {

        if (!interaction.isModalSubmit()) return;
    
        if (interaction.customId === 'informationmodal') {
    
            const informationTitle = interaction.fields.getTextInputValue('informationTitle');
            const informationMain = interaction.fields.getTextInputValue('informationMain');


            const c_member = await interaction.guild.members.fetch(interaction.client.user.id, { force: true });
            
            const anContent = new EmbedBuilder()
                //.setAuthor({ name: `${interaction.client.user.username}`, iconURL: interaction.client.user.displayAvatarURL({ forceStatic: true }) })
                .setColor(c_member.displayHexColor === '#000000' ? '#ffffff' : c_member.displayHexColor)
                
                .setTitle(`${informationTitle}`)
                .setDescription(stripIndents`${informationMain}`)
                .setImage('https://cdn.discordapp.com/attachments/1171284974129918013/1174246171900923984/INFORMATION_SECTION.png')
                .setTimestamp();            
    

            await interaction.channel.send({ embeds: [anContent]}).catch(err => console.log(err.message));
        }
    }
}
