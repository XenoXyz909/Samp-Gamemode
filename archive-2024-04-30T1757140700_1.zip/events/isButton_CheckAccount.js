const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, message, client) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'checkaccount') 
        {
            const errorEmbed = new EmbedBuilder()
            .setColor('#e11e1e')
            .setThumbnail('https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=')
            .setTitle('Cek Akun - Ranum Roleplay')

            const c_member = await interaction.guild.members.fetch(interaction.client.user.id, { force: true });

            const ckaEmbed = new EmbedBuilder()
                .setColor(c_member.displayHexColor === '#000000' ? '#ffffff' : c_member.displayHexColor)

            var member = interaction.member;
            const userID = interaction.user.id;

            const [ rows ] = await connection.execute(
                `SELECT * FROM accounts WHERE DiscordID = ?`, [ `${interaction.user.id}` ]
            );

            if (rows.length === 0) {
                await interaction.reply({ embeds: [
                    errorEmbed
                        .setDescription('Kamu tidak memiliki accounts sama sekali.')
                ], ephemeral: true }).catch(err => console.log(err.message));
                return;
            }

            try {
                await interaction.member.setNickname(`${rows[0].Username}`);
            }
            catch (err){
                console.error(err);
            }

            let members = interaction.member;
            let role = interaction.guild.roles.cache.get('1171284533035937837');

            try {
                await interaction.member.roles.add(role);
            }
            catch (err){
                console.error(err);
            }

            await interaction.reply({ embeds: [
                ckaEmbed
                    .setColor('Blue')
                    .setTitle(`Cek Akun - Ranum Roleplay`)
                    .setThumbnail('https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=')
                    .setDescription(stripIndents`:white_check_mark: Berhasil!
                    Pengecekan UCP berhasil, berikut adalah Nama UCP mu!
                    `)
                    .addFields({ name: "Nama UCP", value: `${rows[0].Username}` })
                    .addFields({ name: "Note", value: `~ Jangan beritahu informasi ini kepada orang lain! ~`})
            ], ephemeral: true }).catch(err => console.log(err.message));
        }
    }
}