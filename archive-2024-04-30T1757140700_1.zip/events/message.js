const {
    Events,
    EmbedBuilder,
    ButtonStyle,
    ButtonBuilder,
    ActionRowBuilder,
  } = require("discord.js");
  

module.exports = {
    name: 'messageCreate',
    async execute(message, client, interaction) {
        if (message.author.bot) return;
        if (message.content.includes("<@1062277730378448988"))  { //your bot id
           
           
          const pingEmbed = new EmbedBuilder()
          
            .setColor("Blue")
            .setTitle("🏓 • Who mentioned me??")
            .setDescription(
              `Hey there ${message.author.username}!, here is some useful information about me.`
            )
    
            .addFields({ name: `🏡 • Servers: **`, value: `${client.guilds.cache.size}`, inline: false })
            .addFields({ name: `👥 • Users: **`, value: `${client.users.cache.size}`, inline: false})
            .addFields({ name: `💣 • Commands: **`, value: `${client.commands.size}`, inline: false})
            .setTimestamp()
            .setThumbnail(`https://cdn.discordapp.com/attachments/1104039014526369892/1104039014958370866/Logo_Transparan_Ranum.png`) // any image you would like
            .setFooter({text: `Requested by ${message.author.username}.`})
    
          return message.reply({ embeds: [pingEmbed]});
        }
      },
}