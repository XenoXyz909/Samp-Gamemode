const { EmbedBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

let connection;

const bcrypt = require('bcrypt');
const saltRounds = 10;

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {

        if (!interaction.isModalSubmit()) return;

        connection = await require('../database/mysql');

        const c_member = await interaction.guild.members.fetch(interaction.client.user.id, { force: true });

        if (interaction.customId === 'changepwmodal') {
    
            const errorEmbed = new EmbedBuilder()
                .setColor('e31e1e')
                .setThumbnail('https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=')
                .setTitle('Ganti Sandi - Ranum Roleplay')
    
            const accEmbed = new EmbedBuilder()
                .setColor(c_member.displayHexColor === '#000000' ? '#ffffff' : c_member.displayHexColor)
    
            const newpasswordCheck = interaction.fields.getTextInputValue('newPWInput');
    
            try {
                const [ rows ] = await connection.execute(
                    `SELECT * FROM accounts WHERE DiscordID = ?`, [`${interaction.user.id}`]
                );
    
                await rows.map(async r => {
                    const password = newpasswordCheck;

                    await bcrypt.hash(password, saltRounds).then(async function(hash) {
                            await connection.query(
                                `UPDATE accounts
                                SET password = '${hash}'
                                WHERE DiscordID = '${interaction.user.id}';`
                            );
                            //console.log(`UPDATE accounts SET password = '${hash}' WHERE DiscordID = '${interaction.user.id}'`)
                            console.log(`INFO: Account: ${r.Username} has changed his password! [ ${interaction.user.tag} ]`);
                    
                            await interaction.reply({ embeds: [
                                accEmbed
                                    .setTitle(`Ganti Sandi - Ranum Roleplay`)
                                    .setColor('Blue')
                                    .setThumbnail('https://media.discordapp.net/attachments/1171285012960792626/1171303061520654356/image.png?ex=655c2ffb&is=6549bafb&hm=bf46a23650a30d7c5a5c128be6481edcf450b6e4417f5a73a4357da58cd858f1&=')
                                    .setDescription(stripIndents`:white_check_mark: Berhasil!
                                    Password berhasil dirubah, berikut adalah kata sandi baru kamu!`)
                                    .addFields({ name: "Kata Sandi Baru", value: `||${password}||`})
                                    .addFields({ name: "Note", value: `~ Jangan beritahu informasi ini kepada orang lain! ~`})
                            ], ephemeral: true }).catch(err => console.log(err.message));
                        });

                    return;
                });
            } catch (err) {
                console.log(err);

                await interaction.reply({ embeds: [
                    errorEmbed
                        .setDescription('Terjadi kesalahan saat mengganti password, silahkan coba lagi.')
                ], ephemeral: true }).catch(err => console.log(err.message));
                return;
            }
        }

    }
}
